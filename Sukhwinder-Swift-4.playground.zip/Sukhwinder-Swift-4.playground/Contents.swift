import UIKit

/*
 Objective
 Create a base protocol with common properties or methods for monsters.
 Derive two child protocols for specific monster types.
 Create four classes (two flying and two water monsters) conforming to these child protocols.
 Write a function that accepts a collection of Monster objects and prints details about each.
 Instructions
 Step 1: Define the Base Protocol
 Monster with:
 var name: String { get }
 func roar() -> String
 Step 2: Define Child Protocols
 FlyingMonster with:
 var wingSpan: Double { get }
 func fly() -> String
 WaterMonster with:
 var swimSpeed: Int { get }
 func swim() -> String
 Step 3: Create Four Classes
 Dragon and Gryphon conforming to FlyingMonster.
 Kraken and Merfolk conforming to WaterMonster.
 Step 4: Create a Function to Handle Monsters
 printMonsterDetails(monsters: [Monster]) to print information for each monster, using polymorphism to call appropriate methods based on their type.
 Sample Output
 Fire Drake roars fiercely, shaking the ground!
 Fire Drake spreads its 15.0-meter wings and takes to the sky!
 -----------------------
 Sky Hunter screeches with a piercing cry!
 Sky Hunter soars high with its majestic 12.0-meter wings!
 -----------------------
 Sea Terror bellows from the deep, causing waves to crash!
 Sea Terror glides through the water at 20 knots!
 -----------------------
 Coral Queen sings an enchanting melody that stirs the seas!
 Coral Queen swims gracefully at 10 knots!
 -----------------------
*/


// Monster
protocol Monster {
    var name: String { get }
    func roar() -> String
} // Monster


// FlyingMonster
protocol FlyingMonster: Monster {
    var wingSpan: Double { get }
    func fly() -> String
} // Flying Monster

// WaterMonster
protocol WaterMonster: Monster {
    var swimSpeed: Int { get }
    func swim() -> String
} // WaterMonster

// Dragon
class Dragon: FlyingMonster {
    var name: String
    var wingSpan: Double
    
    init(name: String, wingSpan: Double) {
        self.name = name
        self.wingSpan = wingSpan
    } // init
    func roar() -> String {
        return  "\(self.name) roars fiercely, shaking the ground!"
    } // roar
    func fly() -> String {
        return "\(self.name) spreads its \(self.wingSpan)-meter wings and takes to the sky!"
    } // fly
} // Dragon

// Gryphon
class Gryphon: FlyingMonster {
    var name: String
    var wingSpan: Double
    
    init(name: String, wingSpan: Double) {
        self.name = name
        self.wingSpan = wingSpan
    } // init
    func roar() -> String {
        return "\(self.name) screeches with a piercing cry!"
    } // roar
    func fly() -> String {
        return "\(self.name) soars high with its majestic \(self.wingSpan)-meter wings!"
    } // fly
} // Gryphon

// Kraken
class Kraken: WaterMonster {
    var name: String
    var swimSpeed: Int
    
    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    } // init
    func roar() -> String {
        return "\(self.name) bellows from the deep, causing waves to crash!"
    } // roar
    func swim() -> String {
        return "\(self.name) glides through the water at \(swimSpeed) knots!"
    } // swim
} // Kraken

// Merfolk
class Merfolk: WaterMonster {
    var name: String
    var swimSpeed: Int
    
    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    } // init
    func roar() -> String {
        return "\(self.name) sings an enchanting melody that stirs the seas!"
    } // roar
    func swim() -> String {
        return "\(self.name) swims gracefully at \(self.swimSpeed) knots!"
    } // swim
} // Merfolk

// function to print Monster Details
func printMonsterDetails(monsters: [Monster]) {
    for monster in monsters {
        print("\(monster.roar())")
        if let flyingMonster = monster as? FlyingMonster {
            print("\(flyingMonster.fly())")
        }
        else if let waterMonster = monster as? WaterMonster {
            print("\(waterMonster.swim())")
        }
        print("-----------------------\n")
    } // for monster loops
} // function printMonsterDetails

// testing the instances of Monsters
let dragon: Dragon = Dragon(name: "Fire Drake" , wingSpan: 15.0)
let gryphon: Gryphon = Gryphon(name: "Sky Hunter", wingSpan: 12.0)
let kraken: Kraken = Kraken(name: "Sea Terror", swimSpeed: 20)
let merfolk: Merfolk = Merfolk(name: "Coral Queen", swimSpeed: 10)
let monsters: [Monster] = [dragon, gryphon, kraken, merfolk]
// printing the details
printMonsterDetails(monsters: monsters)



